//
//  AlamofireVeiwControllerViewController.swift
//  weatherApp
//
//  Created by Даниил Алексеев on 08.11.2020.
//

import UIKit

class AlamofireVeiwControllerViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
